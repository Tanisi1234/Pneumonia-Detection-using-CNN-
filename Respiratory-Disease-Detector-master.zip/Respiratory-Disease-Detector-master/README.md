# Respiratory-Disease-Detector
AI based respiratory disease detector based on breathing sound analysis
